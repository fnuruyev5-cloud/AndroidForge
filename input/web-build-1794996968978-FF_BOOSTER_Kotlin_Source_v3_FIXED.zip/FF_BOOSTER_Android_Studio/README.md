# FF BOOSTER — Kotlin Android source project

## Included
- Kotlin + Jetpack Compose Android app
- Login screen (demo gate password: `FREEFIRE2021`)
- Supplied FF BOOSTER logo used in the UI and launcher icon
- Supplied MP4 video used as a muted looping background
- Free Fire / Free Fire MAX package detection and launch shortcut
- Android RAM, storage and thermal status readings refreshed while the app is open
- USB debugging status and shortcut to Android Developer Options
- WhatsApp contact button for +994 77 367 42 41
- Floating monitor menu placeholder (not implemented in this build)

## Build
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then use:
`Build > Build Bundle(s) / APK(s) > Build APK(s)`

## Important limitations
- This is source code, not a prebuilt APK. It has not been compiled or tested on a physical device in this environment.
- The demo password is embedded in the app and can be extracted; do not use it to protect private data.
- Android only exposes selected system metrics to ordinary apps. RAM/thermal readings are refreshed every 3 seconds while this screen is active; exact device-wide CPU load and other apps' process details may be unavailable.
- The app does not modify Free Fire, inject code, automate gameplay, or guarantee FPS gains.
- USB debugging cannot be enabled by this app. It only reads the status where Android permits and opens Developer Options.
- The floating monitor item is a placeholder for a later version.
