# F2 PROXY ADNA V1.5

## Demo giriş
- İstifadəçi adı: `F2`
- Şifrə: `21`

## Dəyişikliklər
- Mobil ekrana uyğun parlaq qırmızı/qara dizayn.
- Göndərdiyiniz F2 PROXY ADNA loqosu tətbiq ekranına və Android tətbiq ikonuna əlavə olunub.
- Giriş yadda saxlanır; tətbiqi yenidən açanda giriş ekranına səbəbsiz qayıtmır.
- VIP statusu standart olaraq açıqdır və yadda saxlanır.
- Əsas səhifə, Proxy, FF Panel, Ayarlar, Loglar, Haqqımızda düymələri işləyir.
- VPN DEMO Android-in VPN icazə pəncərəsini və sistem VPN göstəricisini göstərməyə cəhd edir. Bu demo heç bir route əlavə etmir, interneti şifrələmir və real VPN serverinə qoşulmur.
- Free Fire faylları dəyişdirilmir.

## APK almaq
Bu layihəni GitHub repozitoriyasının kökünə tam strukturla yükləyin. GitHub Actions → Build F2 PROXY APK → Run workflow. Nəticədə `F2-PROXY-V1.5-APK` artifact-ini endirin.

## Vacib
`gradlew` launcher bu ZIP-də var. GitHub Actions workflow Gradle 8.9-u özü quraşdırır; lokal build üçün Gradle quraşdırılmış olmalıdır.


## V1.5 düzəlişləri
- Üzən düymədə artıq sadə “F2” yazısı deyil, təqdim edilən F2 PROXY ADNA loqosu görünür.
- Üzən paneldə VIP, Proxy demo, Free Fire başlatma və Aim Drak / Aim Kort / HS-ESKOLE / DESERT+ 90HS vizual seçimləri var. Bu seçimlər oyunun nişanalmasına və fayllarına müdaxilə etmir.
- Free Fire və Free Fire MAX paketləri üçün Android package visibility sorğuları əlavə edildi.
- APK launcher icon-u F2 PROXY ADNA loqosudur.
- Qeyd: burada APK kompilyasiya edilməyib; GitHub Actions nəticəsini yoxlamaq lazımdır. Proxy hələ demo-dur, real VPN serveri deyil.
