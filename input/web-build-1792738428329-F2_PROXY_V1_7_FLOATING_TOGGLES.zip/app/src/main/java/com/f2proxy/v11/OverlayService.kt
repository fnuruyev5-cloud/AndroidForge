package com.f2proxy.v11

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.net.Uri
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: LinearLayout? = null
    private var vipOn = true
    private val featureStates = mutableMapOf("Aim Drak" to false, "Aim Kort" to false, "HS-ESKOLE" to false, "DESERT+ 90HS" to false)
    private val red = Color.rgb(255, 12, 58)
    private val black = Color.rgb(16, 14, 20)

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (bubble == null) showBubble()
        return START_STICKY
    }
    private fun overlayType() = if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(w, h, overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 18; y = 180 }

    private fun showBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        // Use the same F2 PROXY ADNA logo as the installed APK icon.
        bubble = ImageView(this).apply {
            setImageResource(R.drawable.f2_proxy_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "F2 PROXY ADNA üzən menyusu"
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(black); shape = android.graphics.drawable.GradientDrawable.OVAL
                setStroke(dp(2), red)
            }
            setPadding(dp(5), dp(5), dp(5), dp(5))
            elevation = dp(8).toFloat()
            setOnClickListener { togglePanel() }
            setOnTouchListener(DragTouchListener { dx, dy ->
                val p = layoutParams as WindowManager.LayoutParams
                p.x += dx; p.y += dy
                try { wm.updateViewLayout(this, p) } catch (_: Exception) {}
            })
        }
        wm.addView(bubble, params(dp(58), dp(58)))
    }

    private fun togglePanel() {
        if (panel != null) { try { wm.removeView(panel) } catch (_: Exception) {}; panel = null; return }
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(black); cornerRadius = dp(20).toFloat(); setStroke(dp(2), red)
            }
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.f2_proxy_logo); scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "F2 PROXY ADNA logo"
        }, LinearLayout.LayoutParams(dp(66), dp(66)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(9), 0, 0, 0) }
        titles.addView(label("F2 PROXY ADNA", 17f, red, true))
        titles.addView(label("VIP PANEL  •  V1.7", 11f, Color.LTGRAY, false))
        header.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        shell.addView(header)
        shell.addView(label("F2 panel • seçimləri ayrıca aç/bağla", 11f, Color.LTGRAY, false))
        val scroll = ScrollView(this).apply { isFillViewport = false; isVerticalScrollBarEnabled = false }
        val options = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        // User requested that VPN/proxy-connect and Free Fire launch controls be removed
        // from the floating panel. Every remaining option has its own ON/OFF toggle.
        options.addView(actionButton(if (vipOn) "★  VIP: AÇIQ  •  BAĞLA" else "★  VIP: BAĞLI  •  AÇ") {
            vipOn = !vipOn
            refreshPanel()
        })
        featureStates.keys.toList().forEach { feature ->
            val enabled = featureStates[feature] == true
            options.addView(actionButton("✦  $feature: " + if (enabled) "AÇIQ  •  BAĞLA" else "BAĞLI  •  AÇ") {
                featureStates[feature] = !(featureStates[feature] ?: false)
                Toast.makeText(this@OverlayService,
                    "$feature: " + if (featureStates[feature] == true) "AÇIQ (vizual demo)" else "BAĞLI",
                    Toast.LENGTH_SHORT).show()
                refreshPanel()
            })
        }
        options.addView(actionButton("✕  MENYUNU BAĞLA") { togglePanel() })
        scroll.addView(options)
        shell.addView(scroll, LinearLayout.LayoutParams(-1, dp(360)))
        panel = shell
        val p = params(dp(292), WindowManager.LayoutParams.WRAP_CONTENT).apply {
            x = dp(12); y = dp(100)
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        }
        try { wm.addView(shell, p) } catch (e: Exception) {
            panel = null
            Toast.makeText(this, "Üzən menyu açılmadı. Ekran üstü icazəsini yoxla.", Toast.LENGTH_LONG).show()
        }
    }

    private fun refreshPanel() {
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        panel = null
        togglePanel()
    }
    private fun label(s: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply { text = s; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(6), 0, dp(6)) }
    private fun actionButton(s: String, click: () -> Unit) = Button(this).apply { text = s; textSize = 12f; isAllCaps = false; setTextColor(Color.WHITE); minHeight = dp(44); background = android.graphics.drawable.GradientDrawable().apply { setColor(Color.rgb(190, 0, 42)); cornerRadius = dp(11).toFloat(); setStroke(dp(1), Color.rgb(255, 65, 106)) }; setOnClickListener { click() } }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() { try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}; try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}; bubble = null; panel = null; super.onDestroy() }

    private class DragTouchListener(val move: (Int, Int) -> Unit) : View.OnTouchListener {
        private var downX = 0f; private var downY = 0f; private var lastX = 0f; private var lastY = 0f; private var dragging = false
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; lastX = e.rawX; lastY = e.rawY; dragging = false; return true }
                MotionEvent.ACTION_MOVE -> { val dx = (e.rawX - lastX).toInt(); val dy = (e.rawY - lastY).toInt(); if (kotlin.math.abs(e.rawX - downX) > 8 || kotlin.math.abs(e.rawY - downY) > 8) dragging = true; if (dragging) move(dx, dy); lastX = e.rawX; lastY = e.rawY; return true }
                MotionEvent.ACTION_UP -> { if (!dragging) v.performClick(); return true }
            }; return false
        }
    }
}
