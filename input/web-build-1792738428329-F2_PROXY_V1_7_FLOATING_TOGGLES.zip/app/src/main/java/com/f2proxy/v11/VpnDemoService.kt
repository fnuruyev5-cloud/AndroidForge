package com.f2proxy.v11

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor

/** A clearly labelled demo interface. It intentionally adds NO routes and does not tunnel traffic. */
class VpnDemoService : VpnService() {
    private var tunnel: ParcelFileDescriptor? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { closeTunnel(); stopSelf(); return START_NOT_STICKY }
        try {
            closeTunnel()
            // No routes are added: normal internet traffic remains on Wi-Fi/mobile data.
            tunnel = Builder().setSession("F2 PROXY VPN DEMO").addAddress("10.23.0.2", 32).establish()
            isRunning = tunnel != null
        } catch (_: Exception) { isRunning = false; stopSelf() }
        return START_NOT_STICKY
    }
    private fun closeTunnel() { try { tunnel?.close() } catch (_: Exception) {}; tunnel = null; isRunning = false }
    override fun onDestroy() { closeTunnel(); super.onDestroy() }
    override fun onBind(intent: Intent?) = super.onBind(intent)
    companion object { @Volatile var isRunning: Boolean = false }
}
