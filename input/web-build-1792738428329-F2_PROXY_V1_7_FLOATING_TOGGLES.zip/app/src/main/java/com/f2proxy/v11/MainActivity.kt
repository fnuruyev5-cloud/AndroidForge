package com.f2proxy.v11

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 6, 10)
    private val card = Color.rgb(22, 17, 25)
    private val red = Color.rgb(255, 24, 65)
    private val pink = Color.rgb(255, 65, 106)
    private val muted = Color.rgb(190, 180, 194)
    private val prefs by lazy { getSharedPreferences("f2prefs", MODE_PRIVATE) }
    private var proxyOn = false
    private var vipOn = true
    private var currentPage = "Əsas Səhifə"
    private val logs = mutableListOf("F2 PROXY V1.5 başladıldı", "VIP statusu: AÇIQ", "Free Fire fayllarına müdaxilə edilmir")
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private val vpnRequestCode = 71

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        vipOn = prefs.getBoolean("vip", true)
        proxyOn = prefs.getBoolean("vpnDemo", false) && VpnDemoService.isRunning
        if (prefs.getBoolean("logged", false)) showDashboard() else showLogin()
    }

    private fun showLogin() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); isFillViewport = true }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(24), dp(26), dp(24), dp(30)) }
        root.addView(space(8))
        root.addView(ImageView(this).apply { setImageResource(com.f2proxy.v11.R.drawable.f2_proxy_logo); scaleType = ImageView.ScaleType.FIT_CENTER }, lp(-1, 190))
        root.addView(text("F2 PROXY", 31f, red, true, Gravity.CENTER), lp(-1, -2, top = 4))
        root.addView(text("V1.5  •  ADNA EDITION  •  VIP", 12f, muted, true, Gravity.CENTER), lp(-1, -2, top = 7, bottom = 24))
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18)); background = rounded(card, 22, Color.rgb(103, 20, 46), 1) }
        box.addView(text("GİRİŞ / LOGIN", 22f, Color.WHITE, true))
        val username = EditText(this).apply { hint="İstifadəçi adı"; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(muted); textSize=16f; setPadding(dp(14),0,dp(14),0); background=rounded(Color.rgb(31,26,35),14,Color.rgb(84,35,53),1) }
        val password = EditText(this).apply { hint="Şifrə"; setSingleLine(true); inputType=129; setTextColor(Color.WHITE); setHintTextColor(muted); textSize=16f; setPadding(dp(14),0,dp(14),0); background=rounded(Color.rgb(31,26,35),14,Color.rgb(84,35,53),1) }
        box.addView(username, lp(-1,54,top=16)); box.addView(password, lp(-1,54,top=10))
        box.addView(action("DAXİL OL", true) {
            if (username.text.toString().trim().equals("F2", true) && password.text.toString() == "21") {
                prefs.edit().putBoolean("logged", true).apply(); logs.add("Giriş edildi"); showDashboard()
            } else Toast.makeText(this,"Demo giriş: istifadəçi F2, şifrə 21",Toast.LENGTH_LONG).show()
        }, lp(-1,56,top=14))
        box.addView(text("Demo giriş: F2  /  21",12f,muted,false),lp(-1,-2,top=10))
        root.addView(box,lp(-1,-2))
        root.addView(text("Yalnız vizual idarəetmə • Free Fire faylları dəyişdirilmir",11f,muted,false,Gravity.CENTER),lp(-1,-2,top=14))
        scroll.addView(root); setContentView(scroll)
    }

    private fun showDashboard() {
        val outer = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(12),dp(10),dp(12),dp(10)) }
        val header = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(12),dp(10),dp(14),dp(10)); background=gradient(intArrayOf(Color.rgb(82,0,22),Color.rgb(28,8,19)),18) }
        header.addView(ImageView(this).apply { setImageResource(R.drawable.f2_proxy_logo); scaleType=ImageView.ScaleType.FIT_CENTER },lp(58,58))
        val brand = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(10),0,0,0) }
        brand.addView(text("F2 PROXY",22f,red,true)); brand.addView(text("V1.5  •  ADNA  •  VIP ${if(vipOn) "AÇIQ" else "BAĞLI"}",11f,Color.WHITE,true),lp(-1,-2,top=3))
        header.addView(brand,LinearLayout.LayoutParams(0,-2,1f))
        status=text(if(proxyOn) "● VPN DEMO" else "● ONLINE",12f,if(proxyOn) pink else Color.rgb(57,255,122),true,Gravity.END); header.addView(status)
        outer.addView(header,lp(-1,-2))
        val navScroll=HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled=false }
        val nav=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setPadding(0,dp(10),0,dp(10)) }
        listOf("Əsas Səhifə","Proxy","FF Panel","Ayarlar","Loglar","Haqqımızda").forEach { page -> nav.addView(action(navLabel(page),page==currentPage){ openPage(page) },lp(-2,42,right=7)) }
        navScroll.addView(nav); outer.addView(navScroll)
        val scroll=ScrollView(this).apply { isFillViewport=true }
        content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,0,0,dp(26)) }
        scroll.addView(content); outer.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(outer); openPage(currentPage)
    }

    private fun navLabel(s:String)=when(s){"Əsas Səhifə"->"⌂  Əsas";"FF Panel"->"🎮  FF Panel";"Ayarlar"->"⚙  Ayarlar";"Loglar"->"▤  Loglar";"Haqqımızda"->"ⓘ  Haqqımızda";else->"◎  Proxy"}
    private fun openPage(page:String) {
        currentPage=page; content.removeAllViews()
        content.addView(text(page.uppercase(),25f,red,true),lp(-1,-2,top=6))
        content.addView(text("DAHA PARLAQ. DAHA CANLI. F2 PROXY ADNA",11f,muted,false),lp(-1,-2,top=5,bottom=12))
        when(page) {
            "Əsas Səhifə" -> {
                val hero=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(14),dp(12),dp(12),dp(12)); background=gradient(intArrayOf(Color.rgb(76,0,20),Color.rgb(28,12,26)),18) }
                hero.addView(ImageView(this).apply { setImageResource(R.drawable.f2_proxy_logo); scaleType=ImageView.ScaleType.FIT_CENTER },lp(82,82))
                val hv=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(10),0,0,0) }
                hv.addView(text("VIP PANEL",20f,Color.WHITE,true)); hv.addView(text("ADNA EDITION  •  V1.5",12f,pink,true),lp(-1,-2,top=5)); hv.addView(text("Status: ${if(proxyOn) "VPN DEMO" else "ONLINE"}",12f,muted,false),lp(-1,-2,top=5)); hero.addView(hv,LinearLayout.LayoutParams(0,-2,1f)); content.addView(hero,lp(-1,-2,bottom=10))
                content.addView(infoCard("⚡ PROXY STATUS",if(proxyOn) "VPN DEMO aktivdir • trafik tunel edilmir" else "Hazırdır • Proxy demo bağlıdır"))
                content.addView(infoCard("🛡 TƏHLÜKƏSİZLİK","Free Fire fayllarına müdaxilə edilmir"),lp(-1,-2,top=8))
                content.addView(action("▶  FREE FIRE START",true){launchFreeFire()},lp(-1,54,top=10))
                content.addView(action("◉  F2 ÜZƏN MENYUNU AÇ",false){openOverlay()},lp(-1,50,top=8))
                content.addView(action(if(proxyOn) "■  VPN DEMO-NU DAYANDIR" else "⚡  PROXY / VPN DEMO BAŞLAT",true){toggleProxy()},lp(-1,52,top=8))
                content.addView(action(if(vipOn) "★  VIP AÇIQ — AYARLAR" else "★  VIP-İ AKTİV ET",false){vipOn=true;prefs.edit().putBoolean("vip",true).apply();openPage("FF Panel")},lp(-1,48,top=8))
            }
            "Proxy" -> {
                content.addView(infoCard("PROXY STATUS",if(proxyOn) "● VPN DEMO aktivdir" else "● Hazırdır • Demo bağlantısı bağlıdır"))
                content.addView(text("Region seç",14f,Color.WHITE,true),lp(-1,-2,top=15,bottom=5))
                content.addView(action("ADNA  •  REGION SELECTED",false){Toast.makeText(this,"Region: ADNA",Toast.LENGTH_SHORT).show()},lp(-1,45))
                content.addView(action(if(proxyOn) "■  Proxy-ni Dayandır" else "▶  Proxy-ni Başlat",true){toggleProxy()},lp(-1,54,top=12))
                content.addView(text("VPN işarəsi üçün Android təsdiqi tələb oluna bilər. Bu DEMO interneti VPN serverindən keçirmir və şifrələmir.",12f,muted,false),lp(-1,-2,top=12))
            }
            "FF Panel" -> {
                content.addView(infoCard("F2 VIP PANEL",if(vipOn) "★ VIP AÇIQ • vizual panel aktivdir" else "VIP bağlıdır"))
                content.addView(action(if(vipOn) "★ VIP AKTİVDİR — BAĞLA" else "★ VIP-İ AÇ",true){vipOn=!vipOn;prefs.edit().putBoolean("vip",vipOn).apply();logs.add("VIP: $vipOn");openPage(page)},lp(-1,50,top=9))
                listOf("Aim Drak","Aim Kort","HS-ESKOLE","DESERT+ 90HS").forEach { f->content.addView(action("✦  $f  •  VİZUAL",false){logs.add("$f vizual seçim");Toast.makeText(this,"Yalnız vizual demo — oyuna təsir etmir",Toast.LENGTH_SHORT).show()},lp(-1,48,top=8)) }
                content.addView(text("Bu düymələr yalnız interfeys seçimidir; nişanalmanı və oyun prosesini dəyişmir.",12f,muted,false),lp(-1,-2,top=12))
            }
            "Ayarlar" -> {
                content.addView(infoCard("TƏTBİQ AYARLARI","F2 PROXY ADNA • V1.5 • qırmızı/qara neon görünüş"))
                content.addView(action("ÜZƏN MENYU İCAZƏSİ",true){openOverlay()},lp(-1,48,top=9))
                content.addView(action("VIP: ${if(vipOn) "AÇIQ" else "BAĞLI"}",false){vipOn=!vipOn;prefs.edit().putBoolean("vip",vipOn).apply();openPage(page)},lp(-1,48,top=8))
                content.addView(action("GİRİŞİ YADDA SAXLAMAĞI SİL / ÇIXIŞ",false){prefs.edit().putBoolean("logged",false).apply();showLogin()},lp(-1,48,top=8))
            }
            "Loglar" -> {
                content.addView(infoCard("SON HADİSƏLƏR",logs.asReversed().joinToString("\n\n")))
                content.addView(action("LOGLARI TƏMİZLƏ",false){logs.clear();logs.add("Loglar təmizləndi");openPage(page)},lp(-1,48,top=9))
            }
            else -> { content.addView(infoCard("F2 PROXY ADNA","Versiya 1.4\nVIP vizual statusu mövcuddur.\nVPN DEMO işarəsi real VPN bağlantısı demək deyil.\nFree Fire faylları dəyişdirilmir."));content.addView(action("FREE FIRE-İ AÇ",true){launchFreeFire()},lp(-1,50,top=9)) }
        }
    }

    private fun toggleProxy() {
        if(proxyOn) { stopService(Intent(this,VpnDemoService::class.java)); VpnDemoService.isRunning=false; proxyOn=false; prefs.edit().putBoolean("vpnDemo",false).apply(); logs.add("VPN demo dayandırıldı"); Toast.makeText(this,"VPN DEMO dayandırıldı",Toast.LENGTH_SHORT).show(); openPage("Proxy") }
        else { val prep=VpnService.prepare(this); if(prep!=null) startActivityForResult(prep,vpnRequestCode) else startVpnDemo() }
    }
    @Deprecated("Legacy result callback for broad Android compatibility")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) { super.onActivityResult(requestCode,resultCode,data); if(requestCode==vpnRequestCode) { if(resultCode==RESULT_OK) startVpnDemo() else Toast.makeText(this,"VPN icazəsi verilmədi",Toast.LENGTH_SHORT).show() } }
    private fun startVpnDemo() { startService(Intent(this,VpnDemoService::class.java)); proxyOn=true; prefs.edit().putBoolean("vpnDemo",true).apply(); logs.add("VPN DEMO başladıldı; internet tunel edilmir"); Toast.makeText(this,"VPN DEMO aktivdir — real server yoxdur",Toast.LENGTH_LONG).show(); openPage("Proxy") }
    private fun openOverlay() { if(!Settings.canDrawOverlays(this)){startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")));Toast.makeText(this,"İcazəni aktiv et, sonra yenidən bas",Toast.LENGTH_LONG).show()}else{startService(Intent(this,OverlayService::class.java));logs.add("F2 üzən menyusu açıldı");Toast.makeText(this,"F2 üzən menyusu açıldı",Toast.LENGTH_SHORT).show()} }
    private fun launchFreeFire() {
        for (pkg in listOf("com.dts.freefireth", "com.dts.freefiremax")) {
            try {
                val intent = packageManager.getLaunchIntentForPackage(pkg)
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                    logs.add("Free Fire başlatma əmri göndərildi: $pkg")
                    return
                }
            } catch (_: Exception) { /* try the other official package */ }
        }
        logs.add("Free Fire launch intent tapılmadı")
        Toast.makeText(this, "Free Fire açıla bilmədi. Oyunun özünü telefonda açıb yoxla; sonra F2-də yenidən bas.", Toast.LENGTH_LONG).show()
    }
    private fun infoCard(title:String,body:String):View { val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(15),dp(14),dp(15),dp(14));background=gradient(intArrayOf(Color.rgb(31,19,30),Color.rgb(17,14,22)),17)};b.addView(text(title,16f,pink,true));b.addView(text(body,13f,Color.rgb(228,221,231),false),lp(-1,-2,top=8));return b }
    private fun action(label:String,primary:Boolean,click:()->Unit)=TextView(this).apply{ text=label;textSize=13f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);typeface=Typeface.create("sans-serif-medium",Typeface.BOLD);setPadding(dp(12),dp(10),dp(12),dp(10));background=if(primary) gradient(intArrayOf(Color.rgb(255,15,58),Color.rgb(175,0,37)),14) else gradient(intArrayOf(Color.rgb(46,22,36),Color.rgb(25,15,25)),14);elevation=dp(if(primary) 3 else 1).toFloat();setOnClickListener{click()} }
    private fun text(s:String,size:Float,color:Int,bold:Boolean=false,gravity:Int=Gravity.START)=TextView(this).apply{text=s;textSize=size;setTextColor(color);this.gravity=gravity;if(bold)typeface=Typeface.DEFAULT_BOLD}
    private fun rounded(color:Int,radius:Int,stroke:Int,width:Int)=GradientDrawable().apply{setColor(color);cornerRadius=dp(radius).toFloat();setStroke(dp(width),stroke)}
    private fun gradient(colors:IntArray,radius:Int)=GradientDrawable(GradientDrawable.Orientation.TL_BR,colors).apply{cornerRadius=dp(radius).toFloat();setStroke(dp(1),Color.rgb(102,24,48))}
    private fun lp(w:Int,h:Int,top:Int=0,bottom:Int=0,right:Int=0)=LinearLayout.LayoutParams(w,h).apply{if(top!=0)topMargin=dp(top);if(bottom!=0)bottomMargin=dp(bottom);if(right!=0)rightMargin=dp(right)}
    private fun space(h:Int)=View(this).apply{layoutParams=lp(1,dp(h))}
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}
