package com.f2proxy.v11

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.net.Uri
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var proxyOn = false
    private var vipOn = true
    private val red = Color.rgb(235, 0, 38)
    private val black = Color.rgb(16, 14, 20)

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (bubble == null) showBubble()
        return START_STICKY
    }
    private fun overlayType() = if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(w, h, overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 18; y = 180 }

    private fun showBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        bubble = TextView(this).apply {
            text = "F2"; textSize = 18f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            background = android.graphics.drawable.GradientDrawable().apply { setColor(red); shape = android.graphics.drawable.GradientDrawable.OVAL; setStroke(dp(2), Color.WHITE) }
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setOnClickListener { togglePanel() }
            setOnTouchListener(DragTouchListener { dx, dy ->
                val p = layoutParams as WindowManager.LayoutParams
                p.x += dx; p.y += dy
                try { wm.updateViewLayout(this, p) } catch (_: Exception) {}
            })
        }
        wm.addView(bubble, params(dp(58), dp(58)))
    }

    private fun togglePanel() {
        if (panel != null) { try { wm.removeView(panel) } catch (_: Exception) {}; panel = null; return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)); background = android.graphics.drawable.GradientDrawable().apply { setColor(black); cornerRadius = dp(18).toFloat(); setStroke(dp(1), red) } }
        box.addView(label("♛  F2 PROXY V1.1", 19f, red, true))
        box.addView(label("VIP: ${if (vipOn) "AÇIQ" else "BAĞLI"}  •  UI DEMO", 12f, Color.LTGRAY, false))
        box.addView(actionButton(if (proxyOn) "■  PROXY DAYANDIR" else "▶  PROXY BAŞLAT") {
            proxyOn = !proxyOn
            Toast.makeText(this, if (proxyOn) "Proxy demo aktivdir; real bağlantı yoxdur." else "Proxy demo dayandırıldı.", Toast.LENGTH_SHORT).show()
            refreshPanel()
        })
        box.addView(actionButton(if (vipOn) "★ VIP AÇIQ — BAĞLA" else "★ VIP-İ AÇ") { vipOn = !vipOn; refreshPanel() })
        box.addView(actionButton("▶  FREE FIRE-I AÇ") { launchFreeFire() })
        box.addView(actionButton("✕  MENYUNU BAĞLA") { togglePanel() })
        panel = box
        val p = params(dp(270), WindowManager.LayoutParams.WRAP_CONTENT).apply { x = dp(12); y = dp(250); flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN }
        wm.addView(box, p)
    }

    private fun refreshPanel() {
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        panel = null
        togglePanel()
    }
    private fun launchFreeFire() {
        val pm = packageManager
        for (pkg in listOf("com.dts.freefireth", "com.dts.freefiremax")) {
            val i = pm.getLaunchIntentForPackage(pkg)
            if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); return }
        }
        Toast.makeText(this, "Free Fire tapılmadı; quraşdırmanı yoxla.", Toast.LENGTH_LONG).show()
    }
    private fun label(s: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply { text = s; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(6), 0, dp(6)) }
    private fun actionButton(s: String, click: () -> Unit) = Button(this).apply { text = s; textSize = 12f; isAllCaps = false; setTextColor(Color.WHITE); background = android.graphics.drawable.GradientDrawable().apply { setColor(Color.rgb(135, 0, 25)); cornerRadius = dp(10).toFloat() }; setOnClickListener { click() } }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() { try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}; try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}; bubble = null; panel = null; super.onDestroy() }

    private class DragTouchListener(val move: (Int, Int) -> Unit) : View.OnTouchListener {
        private var downX = 0f; private var downY = 0f; private var lastX = 0f; private var lastY = 0f; private var dragging = false
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; lastX = e.rawX; lastY = e.rawY; dragging = false; return true }
                MotionEvent.ACTION_MOVE -> { val dx = (e.rawX - lastX).toInt(); val dy = (e.rawY - lastY).toInt(); if (kotlin.math.abs(e.rawX - downX) > 8 || kotlin.math.abs(e.rawY - downY) > 8) dragging = true; if (dragging) move(dx, dy); lastX = e.rawX; lastY = e.rawY; return true }
                MotionEvent.ACTION_UP -> { if (!dragging) v.performClick(); return true }
            }; return false
        }
    }
}
