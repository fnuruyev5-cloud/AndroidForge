package com.f2proxy.v11

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 7, 11)
    private val card = Color.rgb(21, 19, 25)
    private val red = Color.rgb(220, 0, 35)
    private val muted = Color.rgb(175, 170, 180)
    private var loggedIn = false
    private var currentPage = "Əsas Səhifə"
    private var proxyOn = false
    private var vipOn = true
    private val logs = mutableListOf("F2 PROXY V1.1 başladıldı", "VIP statusu: AÇIQ", "Free Fire fayllarına müdaxilə deaktivdir")
    private lateinit var pageContent: LinearLayout
    private lateinit var pageTitle: TextView
    private lateinit var statusLine: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        showLogin()
    }

    private fun showLogin() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(36), dp(24), dp(24))
            setBackgroundColor(bg)
        }
        root.addView(space(18))
        root.addView(text("♛", 58f, red, true, Gravity.CENTER))
        root.addView(text("F2 PROXY", 29f, red, true, Gravity.CENTER))
        root.addView(text("V1.1  •  ADNA EDITION", 13f, muted, false, Gravity.CENTER).apply { setPadding(0, dp(8), 0, dp(28)) })
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(card, 22, Color.rgb(65, 22, 34), 1)
        }
        box.addView(text("GİRİŞ / LOGIN", 21f, Color.WHITE, false))
        val username = EditText(this).apply {
            hint = "İstifadəçi adı"; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(muted)
            setPadding(dp(14), 0, dp(14), 0); background = rounded(Color.rgb(29, 27, 33), 14, Color.rgb(60, 35, 44), 1)
        }
        val password = EditText(this).apply {
            hint = "Şifrə"; setSingleLine(true); inputType = 129; setTextColor(Color.WHITE); setHintTextColor(muted)
            setPadding(dp(14), 0, dp(14), 0); background = rounded(Color.rgb(29, 27, 33), 14, Color.rgb(60, 35, 44), 1)
        }
        box.addView(username, lp(-1, 52, top = 16))
        box.addView(password, lp(-1, 52, top = 10))
        box.addView(button("DAXİL OL") {
            if (username.text.toString().trim() == "F2" && password.text.toString() == "21") {
                loggedIn = true
                logs.add("Demo hesabı ilə giriş edildi")
                showDashboard()
            } else Toast.makeText(this, "Demo giriş: istifadəçi F2, şifrə 21", Toast.LENGTH_LONG).show()
        }, lp(-1, 54, top = 12))
        box.addView(text("Demo giriş: F2  /  21", 12f, muted, false).apply { setPadding(0, dp(10), 0, 0) })
        root.addView(box, lp(-1, -2, top = 10))
        root.addView(text("Yalnız vizual panel • Oyun faylları dəyişdirilmir", 12f, muted, false, Gravity.CENTER).apply { setPadding(0, dp(12), 0, 0) })
        setContentView(root)
    }

    private fun showDashboard() {
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(10), dp(12), dp(10), dp(10)) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(14), dp(14)); background = rounded(Color.rgb(48, 0, 12), 18, Color.rgb(48, 0, 12), 1)
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(text("♛  F2 PROXY", 22f, red, true))
        brand.addView(text("V1.1  •  ADNA  •  VIP AÇIQ", 12f, muted, false).apply { setPadding(0, dp(4), 0, 0) })
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(text(if (proxyOn) "● VPN DEMO" else "● ONLINE", 12f, if (proxyOn) red else Color.GREEN, true))
        outer.addView(header, lp(-1, -2))

        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(12), 0, 0) }
        val nav = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, dp(8), 0) }
        val contentScroll = ScrollView(this).apply { isFillViewport = true }
        pageContent = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(2), 0, 0, dp(24)) }
        contentScroll.addView(pageContent)
        body.addView(nav, LinearLayout.LayoutParams(dp(118), -1))
        body.addView(contentScroll, LinearLayout.LayoutParams(0, -1, 1f))
        val pages = listOf("⌂  Əsas Səhifə", "◎  Proxy", "🎮  FF Panel", "⚙  Ayarlar", "▤  Loglar", "ⓘ  Haqqımızda")
        pages.forEach { label ->
            val page = label.substringAfter("  ")
            nav.addView(button(label) { openPage(page) }.apply {
                textSize = 12f
                background = rounded(if (currentPage == page) red else Color.rgb(30, 19, 25), 14, Color.rgb(60, 30, 40), 1)
                gravity = Gravity.CENTER
            }, lp(-1, 48, bottom = 6))
        }
        outer.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(outer)
        openPage(currentPage)
    }

    private fun openPage(page: String) {
        currentPage = page
        pageContent.removeAllViews()
        pageContent.addView(text(page.uppercase(), 23f, red, true))
        pageContent.addView(text("DAHA GÜCLÜ. DAHA CANLI. F2 PROXY V1.1", 11f, muted, false).apply { setPadding(0, dp(8), 0, dp(10)) })
        when (page) {
            "Əsas Səhifə" -> {
                pageContent.addView(infoCard("PROXY STATUS", if (proxyOn) "● Aktiv • UI DEMO" else "● Dayandırılıb • UI DEMO"))
                pageContent.addView(infoCard("FF PANEL", "Vizual ayarlar • oyun fayllarına müdaxilə etmir"), lp(-1, -2, top = 8))
                pageContent.addView(infoCard("⚡ Sürətli görünüş", "🛡 Təhlükəsizlik • VIP AÇIQ"), lp(-1, -2, top = 8))
                pageContent.addView(button("▶  FREE FIRE START") { launchFreeFire() }, lp(-1, 54, top = 8))
                pageContent.addView(button("F2 ÜZƏN MENYUNU AÇ") { openOverlay() }, lp(-1, 50, top = 8))
                pageContent.addView(button(if (proxyOn) "■  PROXY DAYANDIR" else "▶  PROXY BAŞLAT") { toggleProxy() }, lp(-1, 50, top = 8))
            }
            "Proxy" -> {
                pageContent.addView(infoCard("PROXY STATUS", if (proxyOn) "● Aktiv • Vizual demo" else "● Hazırdır • Real proxy bağlantısı yoxdur"))
                pageContent.addView(text("Region seç", 14f, Color.WHITE, false).apply { setPadding(0, dp(14), 0, dp(6)) })
                pageContent.addView(button("ADNA  •  REGION") { Toast.makeText(this, "Region: ADNA", Toast.LENGTH_SHORT).show() }, lp(-1, 44))
                pageContent.addView(button(if (proxyOn) "■  Proxy-ni Dayandır" else "▶  Proxy-i Başlat") { toggleProxy() }, lp(-1, 54, top = 12))
                pageContent.addView(text("Qeyd: bu düymə yalnız tətbiqdə demo statusunu dəyişir; interneti VPN/proxy üzərindən yönləndirmir.", 12f, muted, false).apply { setPadding(0, dp(10), 0, 0) })
            }
            "FF Panel" -> {
                pageContent.addView(infoCard("F2 VIP PANEL", if (vipOn) "★ VIP AÇIQ • Bütün vizual seçimlər açıqdır" else "VIP bağlıdır"))
                pageContent.addView(button(if (vipOn) "★ VIP AKTİVDİR — BAĞLA" else "★ VIP-İ AÇ") {
                    vipOn = !vipOn; logs.add("VIP statusu: ${if (vipOn) "AÇIQ" else "BAĞLI"}"); openPage("FF Panel")
                }, lp(-1, 50, top = 10))
                listOf("Aim Drak", "Aim Kort", "HS-ESKOLE", "DESERT+ 90HS").forEach { feature ->
                    pageContent.addView(button("✓  $feature  •  VİZUAL") {
                        logs.add("$feature seçimi basıldı (vizual demo)")
                        Toast.makeText(this, "$feature: vizual demo — oyuna təsir etmir", Toast.LENGTH_SHORT).show()
                    }, lp(-1, 46, top = 8))
                }
                pageContent.addView(text("Bu seçimlər yalnız interfeys nümunəsidir; Free Fire fayllarını, nişanalmanı və oyun prosesini dəyişmir.", 12f, muted, false).apply { setPadding(0, dp(12), 0, 0) })
            }
            "Ayarlar" -> {
                pageContent.addView(infoCard("TƏTBİQ AYARLARI", "F2 PROXY V1.1 • Qırmızı-qara görünüş"))
                pageContent.addView(button("ÜZƏN MENYU İCAZƏSİ") { openOverlay() }, lp(-1, 48, top = 10))
                pageContent.addView(button("VIP: ${if (vipOn) "AÇIQ" else "BAĞLI"}") { vipOn = !vipOn; logs.add("VIP statusu dəyişdirildi"); openPage("Ayarlar") }, lp(-1, 48, top = 8))
                pageContent.addView(button("GİRİŞ EKRANINA QAYIT") { loggedIn = false; showLogin() }, lp(-1, 48, top = 8))
            }
            "Loglar" -> {
                pageContent.addView(infoCard("SON HADİSƏLƏR", logs.asReversed().joinToString("\n\n")))
                pageContent.addView(button("LOGLARI TƏMİZLƏ") { logs.clear(); logs.add("Loglar təmizləndi"); openPage("Loglar") }, lp(-1, 48, top = 10))
            }
            else -> {
                pageContent.addView(infoCard("F2 PROXY ADNA", "Versiya 1.1\nQırmızı-qara vizual idarəetmə paneli.\nVIP vizual statusu aktivdir.\nReal VPN/proxy və oyun modifikasiyası daxil deyil."))
                pageContent.addView(button("Free Fire-i aç") { launchFreeFire() }, lp(-1, 50, top = 8))
            }
        }
    }

    private fun toggleProxy() {
        proxyOn = !proxyOn
        logs.add("Proxy demo: ${if (proxyOn) "başladıldı" else "dayandırıldı"}")
        Toast.makeText(this, if (proxyOn) "Proxy DEMO aktivdir (real bağlantı deyil)." else "Proxy demo dayandırıldı.", Toast.LENGTH_SHORT).show()
        openPage("Proxy")
    }

    private fun openOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "İcazəni aktiv et, sonra F2 üzən menyusunu yenidən aç.", Toast.LENGTH_LONG).show()
        } else {
            startService(Intent(this, OverlayService::class.java))
            logs.add("Üzən F2 menyusu açıldı")
            Toast.makeText(this, "F2 üzən menyusu açıldı.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun launchFreeFire() {
        val packages = listOf("com.dts.freefireth", "com.dts.freefiremax")
        for (pkg in packages) {
            val intent = packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                logs.add("Free Fire açıldı")
                startActivity(intent)
                return
            }
        }
        Toast.makeText(this, "Free Fire tapılmadı. Oyunun quraşdırıldığını yoxla.", Toast.LENGTH_LONG).show()
        logs.add("Free Fire tapılmadı")
    }

    private fun infoCard(title: String, body: String): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = rounded(card, 18, Color.rgb(65, 24, 38), 1) }
        box.addView(text(title, 17f, red, false))
        box.addView(text(body, 13f, Color.LTGRAY, false).apply { setPadding(0, dp(8), 0, 0) })
        return box
    }

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false, gravity: Int = Gravity.START) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); this.gravity = gravity
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun button(label: String, click: () -> Unit) = Button(this).apply {
        text = label; textSize = 13f; setTextColor(Color.WHITE); isAllCaps = false
        background = rounded(red, 14, Color.rgb(115, 0, 24), 1)
        setOnClickListener { click() }
    }

    private fun rounded(color: Int, radius: Int, strokeColor: Int, strokeWidth: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(strokeWidth), strokeColor) }

    private fun lp(w: Int, h: Int, top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(w, h).apply { if (top != 0) topMargin = dp(top); if (bottom != 0) bottomMargin = dp(bottom) }
    private fun space(h: Int) = View(this).apply { layoutParams = lp(1, dp(h)) }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
