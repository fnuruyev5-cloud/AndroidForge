# F2 PROXY V1.1 — ADNA EDITION

## Giriş
- İstifadəçi adı: `F2`
- Şifrə: `21`

## Daxil edilən funksiyalar
- Əsas səhifə düymələri işləkdir.
- Proxy bölməsindəki düymə yalnız tətbiq daxilində DEMO statusunu aktiv/deaktiv edir.
- VIP vizual paneli standart olaraq açıqdır; FF Panel bölməsindən dəyişdirilə bilər.
- Free Fire START düyməsi telefonda quraşdırılmış Free Fire və ya Free Fire MAX tətbiqini açmağa çalışır.
- F2 üzən menyusu üçün Android-in “digər tətbiqlərin üzərində göstər” icazəsi tələb olunur.
- FF Panel seçimləri yalnız vizual nümunədir.

## Vacib
Bu layihə real VPN/proxy serverinə qoşulmur. Free Fire fayllarını oxumur və dəyişdirmir, oyunun yaddaşına müdaxilə etmir və nişanalama sistemini dəyişmir.

## APK yaratmaq
GitHub Actions bölməsində `Build F2 PROXY APK` workflow-unu `Run workflow` ilə başlat. Uğurlu build-dən sonra `F2-PROXY-V1.1-APK` adlı artifact-i yüklə.
