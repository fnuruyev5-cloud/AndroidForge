package com.f2talk.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.PermissionRequest;
import android.webkit.ConsoleMessage;
import android.graphics.Color;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(9, 9, 11));
        getWindow().setNavigationBarColor(Color.rgb(9, 9, 11));
        getWindow().getDecorView().setSystemUiVisibility(0);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(9, 9, 11));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && url.startsWith("com.f2talk.app://login-callback")) {
                    Uri uri = Uri.parse(url);
                    String fragment = uri.getEncodedFragment();
                    String callback = "file:///android_asset/index.html";
                    if (fragment != null && !fragment.isEmpty()) callback += "#" + fragment;
                    view.loadUrl(callback);
                    return true;
                }
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    String[] resources = request.getResources();
                    java.util.ArrayList<String> allowed = new java.util.ArrayList<>();
                    for (String resource : resources) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)
                                || PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) {
                            allowed.add(resource);
                        }
                    }
                    if (!allowed.isEmpty()) request.grant(allowed.toArray(new String[0]));
                    else request.deny();
                });
            }
        });
        setContentView(webView);
        handleAuthCallback(getIntent());
        if (getIntent() == null || getIntent().getData() == null) {
            webView.loadUrl("file:///android_asset/index.html");
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleAuthCallback(intent);
    }

    private void handleAuthCallback(Intent intent) {
        if (webView == null || intent == null || intent.getData() == null) return;
        Uri uri = intent.getData();
        if ("com.f2talk.app".equals(uri.getScheme()) && "login-callback".equals(uri.getHost())) {
            String fragment = uri.getEncodedFragment();
            String callback = "file:///android_asset/index.html";
            if (fragment != null && !fragment.isEmpty()) callback += "#" + fragment;
            webView.post(() -> webView.loadUrl(callback));
        }
    }
    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
