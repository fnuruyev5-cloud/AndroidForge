package com.ffbooster.app

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.StatFs
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.viewinterop.AndroidView
import android.net.Uri
import android.widget.VideoView
import android.media.MediaPlayer
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.draw.alpha
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Bg = Color(0xFF10151F)
private val Panel = Color(0xFF1A2331)
private val Blue = Color(0xFF269DFF)
private val Lime = Color(0xFFB8F34A)
private val Muted = Color(0xFF9AA9BC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var unlocked by remember { mutableStateOf(false) }
            Box(Modifier.fillMaxSize()) {
                VideoBackground()
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.76f)))
                if (unlocked) BoosterApp() else LoginScreen(onUnlock = { unlocked = true })
            }
        }
    }
}


private const val APP_PASSWORD = "FREEFIRE2021"

@Composable
private fun VideoBackground() {
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx ->
            VideoView(ctx).apply {
                setOnPreparedListener { player: MediaPlayer ->
                    player.isLooping = true
                    player.setVolume(0f, 0f)
                    start()
                }
                setVideoURI(Uri.parse("android.resource://${ctx.packageName}/${R.raw.intro}"))
            }
        }
    )
}

@Composable
private fun LoginScreen(onUnlock: () -> Unit) {
    val context = LocalContext.current
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().padding(26.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(R.drawable.ff_booster_logo),
            contentDescription = "FF BOOSTER loqosu",
            modifier = Modifier.size(210.dp),
            contentScale = ContentScale.Fit
        )
        Spacer(Modifier.height(18.dp))
        Text("FF BOOSTER", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black)
        Text("PERFORMANCE CONTROL", color = Blue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(26.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it; error = false },
            label = { Text("Giriş şifrəsi") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth(),
            isError = error,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                focusedBorderColor = Blue, unfocusedBorderColor = Muted,
                focusedLabelColor = Blue, unfocusedLabelColor = Muted
            )
        )
        if (error) Text("Şifrə yanlışdır", color = Color(0xFFFF7777), fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = { if (password == APP_PASSWORD) onUnlock() else error = true },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Blue),
            shape = RoundedCornerShape(14.dp)
        ) { Text("DAXİL OL", fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(
            onClick = {
                val uri = Uri.parse("https://wa.me/994773674241?text=Salam%2C%20FF%20BOOSTER%20haqq%C4%B1nda%20m%C9%99lumat%20ist%C9%99yir%C9%99m.")
                try { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                catch (_: Exception) { android.widget.Toast.makeText(context, "WhatsApp bağlantısı açıla bilmədi.", android.widget.Toast.LENGTH_LONG).show() }
            },
            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Lime)
        ) { Icon(Icons.Default.Chat, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("WHATSAPP İLƏ ƏLAQƏ") }
        Spacer(Modifier.height(16.dp))
        Text("Şifrə tətbiqin daxilində saxlanılır; bu, təhlükəsiz hesab sistemi deyil.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun BoosterApp() {
    val context = LocalContext.current
    var selected by remember { mutableStateOf("Ana səhifə") }
    var refresh by remember { mutableIntStateOf(0) }
    var cpuUsage by remember { mutableStateOf("Yoxlanılır…") }
    LaunchedEffect(Unit) {
        while (true) {
            refresh++
            cpuUsage = withContext(Dispatchers.IO) { readCpuUsage() }
            delay(3000)
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Blue,
            secondary = Lime,
            background = Bg,
            surface = Panel
        )
    ) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    listOf("Ana səhifə", "Oyun", "Sistem", "Ayarlar").forEach { item ->
                        NavigationBarItem(
                            selected = selected == item,
                            onClick = { selected = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        "Oyun" -> Icons.Default.SportsEsports
                                        "Sistem" -> Icons.Default.Memory
                                        "Ayarlar" -> Icons.Default.Settings
                                        else -> Icons.Default.Home
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Lime,
                                selectedTextColor = Lime,
                                indicatorColor = Blue.copy(alpha = 0.18f),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            when (selected) {
                "Oyun" -> GameScreen(context, Modifier.padding(padding))
                "Sistem" -> SystemScreen(context, refresh, cpuUsage, Modifier.padding(padding))
                "Ayarlar" -> SettingsScreen(context, Modifier.padding(padding))
                else -> HomeScreen(context, refresh, cpuUsage, onRefresh = { refresh++ },
                    onOpenGame = { selected = "Oyun" }, Modifier.padding(padding))
            }
        }
    }
}

@Composable
private fun ScreenTitle(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        Text(subtitle, color = Muted, fontSize = 13.sp)
    }
}

@Composable
private fun HomeScreen(
    context: Context, refresh: Int, cpuUsage: String, onRefresh: () -> Unit,
    onOpenGame: () -> Unit, modifier: Modifier = Modifier
) {
    val memory = remember(refresh) { readMemory(context) }
    val storage = remember(refresh) { readStorage() }
    val game = remember(refresh) { findGame(context) }

    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 18.dp),
        contentPadding = PaddingValues(top = 22.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painter = painterResource(R.drawable.ff_booster_logo), contentDescription = null,
                    modifier = Modifier.size(54.dp), contentScale = ContentScale.Crop)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("FF", color = Lime, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("BOOSTER", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
                }
                Surface(color = Color(0xFF243247), shape = RoundedCornerShape(50)) {
                    Text("ANDROID", color = Blue, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Surface(color = Panel, shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("OYUN ÜÇÜN HAZIRLA", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("Cihaz vəziyyətini yoxla və Free Fire-ı aç.", color = Muted, fontSize = 13.sp)
                    Button(
                        onClick = { launchGame(context) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Blue),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (game != null) "FREE FIRE-I AÇ" else "FREE FIRE TAPILMADI")
                    }
                    Text(game ?: "Free Fire və Free Fire MAX quraşdırılmayıb və ya görünmür.",
                        color = if (game != null) Lime else Muted, fontSize = 12.sp)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("RAM", memory, "İstifadə olunan", Modifier.weight(1f))
                MetricCard("YADDAŞ", storage, "Boş yer", Modifier.weight(1f))
            }
        }
        item {
            MetricCard("CPU", cpuUsage, "Təxmini sistem yüklənməsi", Modifier.fillMaxWidth())
        }
        item {
            Surface(color = Panel, shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("SİSTEM YOXLAMASI", color = Color.White, fontWeight = FontWeight.Bold)
                    StatusLine("USB Debugging", usbDebugStatus(context))
                    StatusLine("Termal vəziyyət", thermalStatus(context))
                    StatusLine("Oyun bağlantısı", if (game != null) "Oyun tapıldı" else "Oyun tapılmadı")
                }
            }
        }
        item {
            OutlinedButton(onClick = onRefresh, modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("MƏLUMATLARI YENİLƏ")
            }
        }
        item {
            Text("Qeyd: Bu tətbiq Android-in icazə verdiyi göstəriciləri oxuyur. FPS artımına zəmanət vermir.",
                color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, caption: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Panel, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(title, color = Blue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(value, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text(caption, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun StatusLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Muted, fontSize = 13.sp)
        Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun GameScreen(context: Context, modifier: Modifier = Modifier) {
    val game = remember { findGame(context) }
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        ScreenTitle("Oyun rejimi", "Free Fire üçün təhlükəsiz başladıcı")
        Surface(color = Panel, shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Default.SportsEsports, contentDescription = null, tint = Blue,
                    modifier = Modifier.size(34.dp))
                Text("Free Fire bağlantısı", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(game ?: "Uyğun Free Fire paketi tapılmadı.", color = Muted)
                Button(onClick = { launchGame(context) }, modifier = Modifier.fillMaxWidth()) {
                    Text("OYUNU AÇ")
                }
            }
        }
        Text("Tətbiq oyunun fayllarını dəyişmir, oyuna kod yeritmir və oyun qaydalarını keçmir.",
            color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun SystemScreen(context: Context, refresh: Int, cpuUsage: String, modifier: Modifier = Modifier) {
    val memory = remember(refresh) { readMemory(context) }
    val storage = remember(refresh) { readStorage() }
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        ScreenTitle("Sistem monitoru", "Cihazın mövcud göstəriciləri")
        MetricCard("RAM", memory, "Android sistemindən oxunur", Modifier.fillMaxWidth())
        MetricCard("DAXİLİ YADDAŞ", storage, "Hazırda boş olan yer", Modifier.fillMaxWidth())
        MetricCard("CPU", cpuUsage, "Təxmini sistem yüklənməsi", Modifier.fillMaxWidth())
        Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                StatusLine("Termal vəziyyət", thermalStatus(context))
                StatusLine("USB Debugging", usbDebugStatus(context))
                Text("CPU göstəricisi /proc/stat məlumatından təxmini hesablanır; bəzi Android cihazları bu məlumatı məhdudlaşdıra bilər.",
                    color = Muted, fontSize = 12.sp)
            }
        }
        OutlinedButton(onClick = {
            context.startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }, modifier = Modifier.fillMaxWidth()) { Text("YADDAŞ AYARLARINI AÇ") }
    }
}

@Composable
private fun SettingsScreen(context: Context, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        ScreenTitle("Ayarlar", "Bağlantı və Android icazələri")
        Surface(color = Panel, shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("USB DEBUGGING", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Status: ${usbDebugStatus(context)}", color = Muted)
                Button(onClick = {
                    val intent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
                    context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Usb, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("DEVELOPER OPTIONS AÇ")
                }
                Text("USB debugging-i Android ayarlarında özün aktivləşdir. FF BOOSTER bunu sənin əvəzinə aça bilməz.",
                    color = Muted, fontSize = 12.sp)
            }
        }
        Surface(color = Panel, shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("ÜZƏN EKRAN", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Üzən monitor paneli növbəti versiya üçün nəzərdə tutulub.", color = Muted, fontSize = 12.sp)
                Text("TƏHLÜKƏSİZLİK", color = Color.White, fontWeight = FontWeight.Bold)
                Text("ADB bağlantısı bu ilkin versiyada kompüterlə yoxlanılmır. Tanımadığın kompüterə USB debugging icazəsi vermə.",
                    color = Muted, fontSize = 12.sp)
            }
        }
    }
}

private fun readCpuUsage(): String {
    return try {
        fun snapshot(): Pair<Long, Long>? {
            val line = java.io.File("/proc/stat").bufferedReader().use { it.readLine() } ?: return null
            val values = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
            if (values.size < 4) return null
            val total = values.sum()
            val idle = values[3] + (values.getOrNull(4) ?: 0L)
            total to idle
        }
        val first = snapshot()
        if (first == null) return "Məhdud"
        Thread.sleep(250)
        val second = snapshot()
        if (second == null) return "Məhdud"
        val totalDelta = second.first - first.first
        val idleDelta = second.second - first.second
        if (totalDelta <= 0L) "Məhdud" else {
            val percent = ((totalDelta - idleDelta) * 100.0 / totalDelta).coerceIn(0.0, 100.0)
            String.format(Locale.US, "%.0f%%", percent)
        }
    } catch (_: Exception) { "Məhdud" }
}

private fun readMemory(context: Context): String {
    val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val info = ActivityManager.MemoryInfo()
    manager.getMemoryInfo(info)
    val used = info.totalMem - info.availMem
    return "${used / 1024 / 1024} / ${info.totalMem / 1024 / 1024} MB"
}

private fun readStorage(): String = try {
    val stat = StatFs(android.os.Environment.getDataDirectory().path)
    val free = stat.availableBytes / (1024 * 1024 * 1024)
    "${free} GB"
} catch (_: Exception) { "Məlumat yoxdur" }

private fun usbDebugStatus(context: Context): String = try {
    val enabled = Settings.Global.getInt(context.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1
    if (enabled) "Aktivdir" else "Söndürülüb"
} catch (_: Exception) { "Oxunmur" }

private fun thermalStatus(context: Context): String {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return "Dəstəklənmir"
    return try {
        val power = context.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        when (power.currentThermalStatus) {
            android.os.PowerManager.THERMAL_STATUS_NONE -> "Normal"
            android.os.PowerManager.THERMAL_STATUS_LIGHT -> "Yüngül istilik"
            android.os.PowerManager.THERMAL_STATUS_MODERATE -> "Orta istilik"
            android.os.PowerManager.THERMAL_STATUS_SEVERE -> "Yüksək istilik"
            android.os.PowerManager.THERMAL_STATUS_CRITICAL -> "Kritik istilik"
            android.os.PowerManager.THERMAL_STATUS_EMERGENCY -> "Təcili istilik"
            android.os.PowerManager.THERMAL_STATUS_SHUTDOWN -> "Söndürülmə həddi"
            else -> "Naməlum"
        }
    } catch (_: Exception) { "Oxunmur" }
}

private fun findGame(context: Context): String? {
    val pm = context.packageManager
    return when {
        pm.getLaunchIntentForPackage("com.dts.freefireth") != null -> "Free Fire"
        pm.getLaunchIntentForPackage("com.dts.freefiremax") != null -> "Free Fire MAX"
        else -> null
    }
}

private fun launchGame(context: Context) {
    val pm = context.packageManager
    val intent = pm.getLaunchIntentForPackage("com.dts.freefireth")
        ?: pm.getLaunchIntentForPackage("com.dts.freefiremax")
    if (intent != null) {
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } else {
        android.widget.Toast.makeText(context, "Free Fire quraşdırılmayıb.", android.widget.Toast.LENGTH_LONG).show()
    }
}
