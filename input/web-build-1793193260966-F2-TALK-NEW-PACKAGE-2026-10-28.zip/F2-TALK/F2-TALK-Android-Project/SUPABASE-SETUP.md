# Supabase setup checklist for F2 TALK

The Supabase project was created separately. This source project uses its project URL and public publishable key through Vite environment variables.

## Required configuration

- Project URL: `https://xmnapegjcraydvrvcmat.supabase.co`
- Publishable key: `sb_publishable_yd5tCDKVCRxcBRasNLTDEw_9I_nOvTk`
- Auth providers: enable Email; optionally enable Google after configuring OAuth.
- Redirect URLs: add the actual hosted app URL and any local development URL you use.
- RLS: keep enabled. Verify policies before public release.

## Schema notes

The current database has profiles, friendships, conversations, conversation_members, messages, rooms, room_members, call_sessions, and call_signals. The current UI only implements selected basic flows. Do not assume the existence of a fully finished chat/call service from the presence of tables alone.
