import React, { useEffect, useState } from 'react';
import {
  MessageCircle, Users, Radio, Phone, UserRound, Settings, LogOut,
  Plus, Send, ShieldCheck, Video, Mic, MonitorUp, ChevronRight, Flame,
  Search, Menu, X, CircleHelp, Wifi, WifiOff
} from 'lucide-react';
import { supabase, supabaseConfigured } from './supabase';

const nav = [
  { id: 'home', label: 'Ana səhifə', icon: Flame },
  { id: 'friends', label: 'Dostlar', icon: Users },
  { id: 'messages', label: 'Mesajlar', icon: MessageCircle },
  { id: 'rooms', label: 'Otaqlar', icon: Radio },
  { id: 'calls', label: 'Zənglər', icon: Phone },
  { id: 'profile', label: 'Profil', icon: UserRound },
];

function Brand() {
  return <div className="brand"><div className="brand-mark">F2</div><div><b>F2 TALK</b><small>CONNECT • TALK • PLAY</small></div></div>;
}

export default function App() {
  const [session, setSession] = useState(null);
  const [page, setPage] = useState('home');
  const [authMode, setAuthMode] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [profile, setProfile] = useState(null);
  const [friends, setFriends] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [messages, setMessages] = useState([]);
  const [activeRoom, setActiveRoom] = useState(null);
  const [draft, setDraft] = useState('');
  const [roomName, setRoomName] = useState('');
  const [friendUsername, setFriendUsername] = useState('');
  const [mobileMenu, setMobileMenu] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    if (!supabaseConfigured) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => setSession(nextSession));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session || !supabase) return;
    loadProfile();
    loadFriends();
    loadRooms();
  }, [session]);

  useEffect(() => {
    if (!session || !activeRoom || !supabase) { setMessages([]); return; }
    loadMessages(activeRoom.id);
    const channel = supabase.channel(`room-messages-${activeRoom.id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${activeRoom.id}` }, payload => {
        setMessages(current => current.some(m => m.id === payload.new.id) ? current : [...current, payload.new]);
      }).subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [session, activeRoom]);

  async function loadProfile() {
    const { data, error } = await supabase.from('profiles').select('*').eq('id', session.user.id).maybeSingle();
    if (error) setNotice(error.message);
    setProfile(data);
  }
  async function loadFriends() {
    const { data, error } = await supabase.from('friendships').select('*')
      .or(`requester_id.eq.${session.user.id},addressee_id.eq.${session.user.id}`).order('created_at', { ascending: false });
    if (error) setNotice(error.message);
    setFriends(data || []);
  }
  async function loadRooms() {
    const { data, error } = await supabase.from('rooms').select('*').order('created_at', { ascending: false });
    if (error) setNotice('Otaqlar yüklənmədi: ' + error.message);
    setRooms(data || []);
  }
  async function loadMessages(conversationId) {
    const { data, error } = await supabase.from('messages').select('*').eq('conversation_id', conversationId).order('created_at');
    if (error) setNotice('Mesajlar yüklənmədi: ' + error.message);
    setMessages(data || []);
  }
  async function authenticate(e) {
    e.preventDefault(); setBusy(true); setNotice('');
    if (!supabaseConfigured) { setNotice('Supabase ayarları yoxdur. .env faylını .env.example əsasında yarat.'); setBusy(false); return; }
    const result = authMode === 'signup'
      ? await supabase.auth.signUp({ email, password, options: { data: { full_name: displayName || email.split('@')[0] } } })
      : await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (result.error) setNotice(result.error.message);
    else if (authMode === 'signup' && !result.data.session) setNotice('Qeydiyyat yaradıldı. E-poçt təsdiqi tələb oluna bilər.');
    else setNotice('Uğurla daxil oldun.');
  }
  async function googleLogin() {
    if (!supabaseConfigured) return setNotice('Əvvəlcə Supabase ayarlarını qur.');
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: 'com.f2talk.app://login-callback' }
    });
    if (error) setNotice(error.message);
  }
  async function logout() { await supabase?.auth.signOut(); setSession(null); setProfile(null); }
  async function createRoom(e) {
    e.preventDefault(); if (!roomName.trim()) return;
    const { data, error } = await supabase.from('rooms').insert({ name: roomName.trim(), created_by: session.user.id }).select().single();
    if (error) setNotice(error.message);
    else {
      const join = await supabase.from('room_members').insert({ room_id: data.id, user_id: session.user.id, role: 'owner' });
      if (join.error) setNotice('Otaq yaradıldı, üzvlük əlavə edilərkən xəta: ' + join.error.message);
      setRoomName(''); setActiveRoom(data); await loadRooms();
    }
  }
  async function joinRoom(room) {
    const { error } = await supabase.from('room_members').upsert({ room_id: room.id, user_id: session.user.id }, { onConflict: 'room_id,user_id' });
    if (error) setNotice(error.message);
    else { setActiveRoom(room); setPage('messages'); }
  }
  async function sendMessage(e) {
    e.preventDefault(); if (!draft.trim() || !activeRoom) return;
    // Messages are stored in the conversations table, not directly in rooms.
    setNotice('Mesajlaşma cədvəli söhbət ID-si tələb edir. Otaq mətn çatının bağlanması növbəti backend addımıdır.');
  }
  async function addFriend(e) {
    e.preventDefault();
    const username = friendUsername.trim().replace(/^@/, '');
    if (!username) return;
    const { data: target, error: findError } = await supabase.from('profiles').select('id,username,display_name').eq('username', username).maybeSingle();
    if (findError || !target) { setNotice('Bu istifadəçi tapılmadı. İstifadəçi adını yoxla.'); return; }
    if (target.id === session.user.id) { setNotice('Özünü dost əlavə edə bilməzsən.'); return; }
    const { error } = await supabase.from('friendships').insert({ requester_id: session.user.id, addressee_id: target.id });
    setNotice(error ? error.message : 'Dostluq sorğusu göndərildi.');
    setFriendUsername(''); loadFriends();
  }
  async function updateProfile(e) {
    e.preventDefault();
    const name = e.currentTarget.displayName.value.trim();
    const bio = e.currentTarget.bio.value.trim();
    const { error } = await supabase.from('profiles').update({ display_name: name, bio, updated_at: new Date().toISOString() }).eq('id', session.user.id);
    setNotice(error ? error.message : 'Profil yadda saxlanıldı.');
    if (!error) loadProfile();
  }

  if (!session) return <div className="auth-shell">
    <div className="auth-art"><div className="glow"></div><Brand /><div className="hero-copy"><span className="eyebrow">YOUR SPACE. YOUR PEOPLE.</span><h1>Söhbətə<br/><em>qoşul.</em></h1><p>Dostlarınla əlaqədə qal. Öz otağını yarat. F2 TALK ilə bir yerdə ol.</p><div className="feature-pills"><span><MessageCircle size={15}/> Mesajlar</span><span><Users size={15}/> Dostlar</span><span><Radio size={15}/> Otaqlar</span></div></div><div className="hero-footer">F2 TALK <span>•</span> COMMUNITY PLATFORM</div></div>
    <div className="auth-panel"><div className="auth-card"><div className="mobile-brand"><Brand /></div><span className="eyebrow">XİDMƏTƏ XOŞ GƏLMİSƏN</span><h2>{authMode === 'login' ? 'Yenidən xoş gəldin' : 'Hesab yarat'}</h2><p className="muted">{authMode === 'login' ? 'Davam etmək üçün hesabına daxil ol.' : 'F2 TALK ailəsinə qoşul.'}</p>
      {!supabaseConfigured && <div className="notice warning">Supabase açarı sazlanmayıb. Bu ZIP-dəki <code>.env.example</code> faylını <code>.env</code> kimi köçürüb ayarları yoxla.</div>}
      <form onSubmit={authenticate} className="auth-form">
        {authMode === 'signup' && <label>Görünən ad<input value={displayName} onChange={e=>setDisplayName(e.target.value)} placeholder="Adın" autoComplete="name" /></label>}
        <label>E-poçt<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="name@example.com" required autoComplete="email" /></label>
        <label>Şifrə<input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Ən azı 6 simvol" required minLength={6} autoComplete={authMode === 'login' ? 'current-password' : 'new-password'} /></label>
        <button className="primary full" disabled={busy}>{busy ? 'Gözlə...' : authMode === 'login' ? 'Daxil ol' : 'Qeydiyyatdan keç'} <ChevronRight size={18}/></button>
      </form>
      <div className="or"><span></span> və ya <span></span></div>
      <button className="google-btn full" onClick={googleLogin}><span className="google-g">G</span> Google ilə davam et</button>
      <p className="switch-auth">{authMode === 'login' ? 'Hesabın yoxdur?' : 'Artıq hesabın var?'} <button onClick={()=>{setAuthMode(authMode === 'login' ? 'signup' : 'login');setNotice('')}}>{authMode === 'login' ? 'Qeydiyyat' : 'Daxil ol'}</button></p>
      {notice && <div className="notice">{notice}</div>}
      <small className="fine-print"><ShieldCheck size={13}/> Hesabın təhlükəsiz autentifikasiya ilə qorunur.</small>
    </div></div>
  </div>;

  const currentPage = nav.find(n=>n.id===page) || nav[0];
  const PageIcon = currentPage.icon;
  return <div className="app-shell">
    <aside className={`sidebar ${mobileMenu?'open':''}`}><Brand/><div className="nav-caption">İŞ SAHƏSİ</div><nav>{nav.map(item=>{const Icon=item.icon;return <button key={item.id} className={`nav-item ${page===item.id?'active':''}`} onClick={()=>{setPage(item.id);setMobileMenu(false)}}><Icon size={18}/><span>{item.label}</span>{item.id==='messages'&&<span className="nav-dot"/>}</button>})}</nav><div className="sidebar-bottom"><div className="online-status"><span className="green-dot"/> Sistemə qoşulub</div><div className="user-mini"><div className="avatar">{(profile?.display_name||session.user.email||'F').slice(0,1).toUpperCase()}</div><div className="user-mini-text"><b>{profile?.display_name || session.user.email?.split('@')[0]}</b><small>@{profile?.username || 'f2user'}</small></div><button className="icon-btn" onClick={logout} title="Çıxış"><LogOut size={17}/></button></div></div></aside>
    {mobileMenu && <button className="scrim" onClick={()=>setMobileMenu(false)} aria-label="Menyunu bağla"/>}
    <main className="main-area"><header className="topbar"><button className="mobile-menu-btn icon-btn" onClick={()=>setMobileMenu(!mobileMenu)}>{mobileMenu?<X/>:<Menu/>}</button><div className="breadcrumb"><span>F2 TALK</span><ChevronRight size={15}/><b>{currentPage.label}</b></div><div className="topbar-right"><div className="connection"><span className="green-dot"/> Online</div><button className="icon-btn" onClick={()=>setPage('profile')} title="Parametrlər"><Settings size={18}/></button></div></header>
      <div className="page-content">
        {notice && <div className="notice global-notice"><span>{notice}</span><button onClick={()=>setNotice('')}><X size={15}/></button></div>}
        {page==='home' && <><div className="welcome-row"><div><span className="eyebrow">F2 COMMUNITY</span><h1>Xoş gəldin, <em>{(profile?.display_name||session.user.email?.split('@')[0]||'dost').split(' ')[0]}</em></h1><p className="muted">Bu gün kimlə söhbət edirik?</p></div><div className="hero-badge"><Flame size={28}/><span>PRO<br/><b>MODE</b></span></div></div>
          <div className="banner"><div className="banner-glow"/><div><span className="eyebrow">YOUR COMMUNITY STARTS HERE</span><h2>Öz dünyanı yarat.</h2><p>Dostlarını dəvət et, otaqlara qoşul və söhbətə başla.</p><button className="primary" onClick={()=>setPage('rooms')}>Otaqları kəşf et <ChevronRight size={17}/></button></div><div className="banner-symbol">F<span>2</span></div></div>
          <div className="section-heading"><h3>Sürətli keçid</h3><span className="muted">Əsas funksiyalar</span></div><div className="quick-grid">{[{id:'friends',icon:Users,title:'Dostlar',desc:'Dostluq sorğularını idarə et',color:'red'},{id:'messages',icon:MessageCircle,title:'Mesajlar',desc:'Söhbətlərinə bax',color:'purple'},{id:'rooms',icon:Radio,title:'Otaqlar',desc:'İcma otaqlarını tap',color:'orange'},{id:'calls',icon:Phone,title:'Zənglər',desc:'Zəng funksiyasını aç',color:'blue'}].map(c=>{const Icon=c.icon;return <button className="quick-card" key={c.id} onClick={()=>setPage(c.id)}><div className={`quick-icon ${c.color}`}><Icon size={21}/></div><div><b>{c.title}</b><p>{c.desc}</p></div><ChevronRight size={17} className="quick-arrow"/></button>})}</div>
          <div className="section-heading"><h3>İcma otaqları</h3><button className="text-btn" onClick={()=>setPage('rooms')}>Hamısına bax <ChevronRight size={15}/></button></div>{rooms.length ? <div className="room-list">{rooms.slice(0,3).map(r=><button key={r.id} className="room-row" onClick={()=>joinRoom(r)}><div className="room-icon"><Radio size={18}/></div><div><b>{r.name}</b><small>{r.description||'F2 TALK otağı'}</small></div><ChevronRight size={17}/></button>)}</div>:<div className="empty-card"><Radio size={24}/><b>Hələ otaq yoxdur</b><span>İlk otağı sən yarat.</span><button className="secondary" onClick={()=>setPage('rooms')}>Otaq yarat</button></div>}</>}
        {page==='friends' && <><div className="page-title"><span className="eyebrow">COMMUNITY</span><h1>Dostlar</h1><p className="muted">Dostlarını tap və söhbətə başla.</p></div><form className="inline-form" onSubmit={addFriend}><input value={friendUsername} onChange={e=>setFriendUsername(e.target.value)} placeholder="@istifadeci_adi"/><button className="primary"><Plus size={17}/> Dost əlavə et</button></form><div className="section-heading"><h3>Dostluq sorğuları</h3><span className="count-pill">{friends.length}</span></div>{friends.length?<div className="data-list">{friends.map(f=><div className="data-row" key={f.id}><div className="avatar">{(f.requester_id===session.user.id?'Göndərilən':'Gələn').slice(0,1)}</div><div className="row-grow"><b>{f.requester_id===session.user.id?'Göndərilən sorğu':'Gələn sorğu'}</b><small>{f.status==='accepted'?'Dostdur':f.status==='pending'?'Gözləyir':'Bloklanıb'}</small></div><span className={`status ${f.status}`}>{f.status}</span></div>)}</div>:<div className="empty-card"><Users size={25}/><b>Hələ dost yoxdur</b><span>İstifadəçi adını yazaraq sorğu göndər.</span></div>}</>}
        {page==='messages' && <><div className="page-title"><span className="eyebrow">PRIVATE CHAT</span><h1>Mesajlar</h1><p className="muted">Söhbətlərin burada görünəcək.</p></div><div className="chat-layout"><div className="chat-sidebar"><div className="search-box"><Search size={16}/><input value={searchTerm} onChange={e=>setSearchTerm(e.target.value)} placeholder="Axtar..."/></div><div className="chat-empty">Söhbət seçilməyib</div></div><div className="chat-window"><div className="chat-placeholder"><div className="quick-icon purple"><MessageCircle size={25}/></div><h3>{activeRoom?.name || 'Söhbətə başla'}</h3><p>Mesajlaşma üçün əvvəlcə söhbət və ya otaq üzvlüyü qurulmalıdır. Otaqlar bölməsindən otaq seçə bilərsən.</p><button className="secondary" onClick={()=>setPage('rooms')}>Otaqlara keç</button></div></div></div></>}
        {page==='rooms' && <><div className="page-title"><span className="eyebrow">F2 COMMUNITIES</span><h1>Otaqlar</h1><p className="muted">İcmanı yarat və dostlarını dəvət et.</p></div><form className="create-room" onSubmit={createRoom}><div><label>Yeni otağın adı</label><input value={roomName} onChange={e=>setRoomName(e.target.value)} placeholder="Məsələn: F2 Gaming" maxLength={80} required/></div><button className="primary"><Plus size={17}/> Otaq yarat</button></form><div className="section-heading"><h3>Otaqları kəşf et</h3><span className="count-pill">{rooms.length}</span></div>{rooms.length?<div className="rooms-grid">{rooms.filter(r=>r.name.toLowerCase().includes(searchTerm.toLowerCase())).map(r=><div className="room-card" key={r.id}><div className="room-card-top"><div className="room-icon"><Radio size={20}/></div><span className="room-live"><span className="green-dot"/> İcma</span></div><h3>{r.name}</h3><p>{r.description||'F2 TALK icma otağı'}</p><div className="room-card-bottom"><small>Otaq ID: {r.id.slice(0,8)}</small><button className="secondary" onClick={()=>joinRoom(r)}>Qoşul <ChevronRight size={15}/></button></div></div>)}</div>:<div className="empty-card"><Radio size={25}/><b>İlk otağı sən yarat</b><span>İcmanı başlatmaq üçün yuxarıdakı formanı doldur.</span></div>}</>}
        {page==='calls' && <><div className="page-title"><span className="eyebrow">REAL-TIME</span><h1>Zənglər</h1><p className="muted">Səs, video və ekran paylaşımı.</p></div><div className="call-feature"><div className="call-orb"><Phone size={32}/></div><span className="eyebrow">COMING TO YOUR COMMUNITY</span><h2>Hər zaman yaxın ol.</h2><p>Bu ZIP versiyasında real WebRTC zəng axını tam qoşulmayıb. Zənglər üçün siqnallaşma, STUN/TURN serveri və cihaz icazələri sazlanmalıdır.</p><div className="call-options"><div><Mic size={20}/><span>Səsli zəng</span></div><div><Video size={20}/><span>Video zəng</span></div><div><MonitorUp size={20}/><span>Ekran paylaşımı</span></div></div><div className="notice warning">Zəng düymələri hələ işlək zəng başlatmır. Bu ekran hazırda məlumat üçündür.</div></div></>}
        {page==='profile' && <><div className="page-title"><span className="eyebrow">YOUR ACCOUNT</span><h1>Profil</h1><p className="muted">Hesab məlumatlarını idarə et.</p></div><form className="profile-card" onSubmit={updateProfile}><div className="profile-head"><div className="avatar big">{(profile?.display_name||session.user.email||'F').slice(0,1).toUpperCase()}</div><div><h3>{profile?.display_name||'F2 User'}</h3><p className="muted">@{profile?.username||'f2user'}</p><span className="status accepted">HESAB AKTİVDİR</span></div></div><label>E-poçt<input value={session.user.email||''} disabled/></label><label>Görünən ad<input name="displayName" defaultValue={profile?.display_name||''} maxLength={80}/></label><label>Haqqımda<textarea name="bio" defaultValue={profile?.bio||''} maxLength={300} rows={3} placeholder="Özün haqqında qısa məlumat"/></label><button className="primary">Dəyişiklikləri yadda saxla</button><button type="button" className="secondary logout-btn" onClick={logout}><LogOut size={16}/> Hesabdan çıx</button></form></>}
      </div>
      <footer className="footer"><span>© 2026 F2 TALK</span><span><span className="green-dot"/> Supabase {supabaseConfigured?'konfiqurasiya olunub':'ayarlanmayıb'}</span><span>Built for community</span></footer>
    </main>
  </div>;
}
