# F2 TALK — Android-ready web app starter

F2 TALK is a mobile-first React/Vite project with a black/red UI, Supabase Auth integration points, profile editing, friend requests, community rooms, and an Android wrapper configuration.

## Important status notes

- This ZIP is a **starter project**, not a verified production release.
- Supabase URL and the publishable key are public client configuration. Never add a Supabase `service_role` key to frontend code.
- Signup/login and profile/room/friend flows are wired to Supabase but must be tested with your project settings and RLS policies.
- The current message screen and voice/video/screen-sharing screens clearly indicate incomplete functionality; real room chat and production WebRTC calling are not fully implemented in this starter.
- Google OAuth requires enabling Google in Supabase Auth and adding the correct redirect URLs.
- Do not advertise calls as working until WebRTC signaling, STUN/TURN and two-device tests succeed.

## 1. Configure Supabase

1. Create a file named `.env` in the project root (copy `.env.example`).
2. Set:
   - `VITE_SUPABASE_URL` to your Supabase Project URL.
   - `VITE_SUPABASE_ANON_KEY` to the project's **publishable** key (or legacy anon key).
3. In Supabase Authentication settings, configure your site's URL and allowed redirect URLs.
4. If email confirmation is enabled, confirm the account using the verification email.
5. Review the database migrations and RLS policies in your Supabase project before putting the app into public use.

Configured project URL:
`https://xmnapegjcraydvrvcmat.supabase.co`

Public publishable key configured for this project:
`sb_publishable_yd5tCDKVCRxcBRasNLTDEw_9I_nOvTk`

These values are public frontend configuration, not administrator secrets. Rotate them if you ever mistakenly expose a secret key.

## 2. Run in development

Install Node.js 20+ and npm.

```bash
npm install
cp .env.example .env
# Edit .env and verify the Supabase URL and public key
npm run dev
```

Open the local URL printed by Vite.

## 3. Build the web version

```bash
npm run build
npm run preview
```

## 4. Build an Android APK with Capacitor

Android APK generation requires Android SDK/build tools and Java. You can use Android Studio on a computer or a compatible cloud build environment.

```bash
npm install
npx cap add android
npm run android:sync
npx cap open android
```

In Android Studio:
1. Wait for Gradle sync to finish.
2. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. Use the APK output path shown by Android Studio.

If `android/` already exists, do not run `npx cap add android` again; run `npm run android:sync`.

## 5. Google sign-in setup

1. Configure the Google provider in Supabase Authentication.
2. Create OAuth credentials in Google Cloud Console.
3. Add the Supabase callback URL shown in the Supabase provider settings to Google Cloud Console.
4. Add the app/site redirect URL to Supabase's allowed redirect URLs.
5. Test login on web and on the installed Android build.

Never ask a user for their Google password or one-time verification code.

## 6. Real-time calls

Voice, video, and screen sharing need a complete WebRTC implementation, authenticated signaling, permission handling, and STUN/TURN configuration. A TURN service may have usage costs. Test calls between two devices and different networks before calling this feature production-ready.

## 7. Security checklist

- Keep service-role keys server-side only.
- Keep Row Level Security enabled on every exposed table.
- Review and test all RLS policies, including private-room and friendship access.
- Add rate limiting and abuse reporting before a public launch.
- Set correct Auth redirect URLs and HTTPS.
- Do not store user passwords in application tables.
