-- F2 TALK: link community rooms to the existing conversation/message tables.
-- Review your current schema and RLS policies before running this in Supabase SQL Editor.

alter table public.conversations
  add column if not exists room_id uuid references public.rooms(id) on delete cascade;

create unique index if not exists conversations_room_id_unique
  on public.conversations(room_id) where room_id is not null;

-- Create one conversation for each existing room that does not already have one.
-- This assumes conversations.id and created_at have defaults and that room_id is nullable.
insert into public.conversations (room_id)
select r.id
from public.rooms r
where not exists (
  select 1 from public.conversations c where c.room_id = r.id
);

-- Keep a conversation row for newly created rooms. The trigger runs with the privileges
-- of the function owner so it can create the linked row even when client RLS is strict.
create or replace function public.f2talk_create_room_conversation()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.conversations (room_id) values (new.id)
  on conflict (room_id) where room_id is not null do nothing;
  return new;
end;
$$;

drop trigger if exists f2talk_room_conversation_after_insert on public.rooms;
create trigger f2talk_room_conversation_after_insert
after insert on public.rooms
for each row execute function public.f2talk_create_room_conversation();

-- IMPORTANT: This migration only adds the room/conversation link. Verify that existing
-- RLS policies permit room members to SELECT/INSERT messages for their conversation.
-- Do not disable RLS to make the app work.
