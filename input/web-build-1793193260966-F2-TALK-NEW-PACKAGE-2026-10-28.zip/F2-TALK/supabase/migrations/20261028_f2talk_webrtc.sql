-- F2 TALK WebRTC signaling tables. Run in Supabase SQL Editor.
create table if not exists public.f2_call_sessions (
  id uuid primary key default gen_random_uuid(),
  caller_id uuid not null references auth.users(id) on delete cascade,
  callee_id uuid not null references auth.users(id) on delete cascade,
  call_type text not null check (call_type in ('audio','video')),
  status text not null default 'ringing' check (status in ('ringing','accepted','ended','rejected')),
  created_at timestamptz not null default now(),
  ended_at timestamptz,
  constraint f2_call_not_self check (caller_id <> callee_id)
);
create index if not exists f2_call_sessions_callee_status_idx on public.f2_call_sessions(callee_id,status,created_at desc);
create table if not exists public.f2_call_signals (
  id uuid primary key default gen_random_uuid(),
  call_id uuid not null references public.f2_call_sessions(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  recipient_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check (kind in ('offer','answer','ice','hangup')),
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists f2_call_signals_call_idx on public.f2_call_signals(call_id,created_at);
alter table public.f2_call_sessions enable row level security;
alter table public.f2_call_signals enable row level security;
drop policy if exists "f2 calls participants read" on public.f2_call_sessions;
create policy "f2 calls participants read" on public.f2_call_sessions for select to authenticated using (auth.uid()=caller_id or auth.uid()=callee_id);
drop policy if exists "f2 caller create call" on public.f2_call_sessions;
create policy "f2 caller create call" on public.f2_call_sessions for insert to authenticated with check (auth.uid()=caller_id);
drop policy if exists "f2 participants update call" on public.f2_call_sessions;
create policy "f2 participants update call" on public.f2_call_sessions for update to authenticated using (auth.uid()=caller_id or auth.uid()=callee_id) with check (auth.uid()=caller_id or auth.uid()=callee_id);
drop policy if exists "f2 call participants read signals" on public.f2_call_signals;
create policy "f2 call participants read signals" on public.f2_call_signals for select to authenticated using (
  exists(select 1 from public.f2_call_sessions c where c.id=call_id and (auth.uid()=c.caller_id or auth.uid()=c.callee_id))
);
drop policy if exists "f2 call participant send signals" on public.f2_call_signals;
create policy "f2 call participant send signals" on public.f2_call_signals for insert to authenticated with check (
  auth.uid()=sender_id and exists(select 1 from public.f2_call_sessions c where c.id=call_id and (auth.uid()=c.caller_id or auth.uid()=c.callee_id) and (recipient_id=c.caller_id or recipient_id=c.callee_id))
);
-- Enable postgres_changes for incoming calls and signaling (skip duplicate membership errors).
do $$ begin
  alter publication supabase_realtime add table public.f2_call_sessions;
exception when duplicate_object then null;
when others then raise notice 'Could not add f2_call_sessions to supabase_realtime: %', sqlerrm;
end $$;
do $$ begin
  alter publication supabase_realtime add table public.f2_call_signals;
exception when duplicate_object then null;
when others then raise notice 'Could not add f2_call_signals to supabase_realtime: %', sqlerrm;
end $$;
