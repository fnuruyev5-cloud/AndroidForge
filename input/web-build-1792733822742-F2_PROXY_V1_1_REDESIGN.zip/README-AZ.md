# F2 PROXY V1.1 — yenilənmiş Android layihəsi

- Giriş: istifadəçi `F2`, şifrə `21` (lokal demo girişidir).
- Qırmızı-qara dashboard, bölmələr və daha dolu FF Panel.
- F2 üzən düyməsi sürüşdürülə və menyunu açıb-bağlaya bilər.
- START quraşdırılmış Free Fire / Free Fire MAX tətbiqini açmağa çalışır.
- Aim Drak, Aim Kort, HS-ESKOLE və DESERT+ 90HS yalnız vizual demo açarlarıdır; oyunun nişanalmasına təsir etmir və oyun fayllarını dəyişmir.
- Real proxy/VPN bağlantısı yoxdur.

## APK build
GitHub repository kökündə `settings.gradle`, `build.gradle`, `app/` və `.github/workflows/build-apk.yml` olmalıdır. Actions -> Build F2 PROXY APK -> Run workflow. Artifact `F2-PROXY-V1.1-APK` kimi yüklənir.
