package com.f2proxy.v11

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button
import android.widget.Toast
import android.graphics.drawable.GradientDrawable

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private val red = Color.rgb(255, 22, 48)
    private val dark = Color.rgb(12, 8, 13)

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (bubble == null) {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            showBubble()
        }
        return START_NOT_STICKY
    }

    private fun type() = if (android.os.Build.VERSION.SDK_INT >= 26)
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE

    private fun lp(w: Int, h: Int, x: Int = 12, y: Int = 110) =
        WindowManager.LayoutParams(w, h, type(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x; this.y = y
        }

    private fun showBubble() {
        val b = TextView(this).apply {
            text = "♛ F2"
            textSize = 16f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(red, Color.rgb(110,0,20))).apply {
                cornerRadius = dp(18).toFloat(); setStroke(dp(1), Color.rgb(255,100,115))
            }
            setOnClickListener { togglePanel() }
        }
        bubble = b
        wm.addView(b, lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT))
        b.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val p = v.layoutParams as WindowManager.LayoutParams
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX; downY = e.rawY; startX = p.x; startY = p.y; moved = false; return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - downX).toInt(); val dy = (e.rawY - downY).toInt()
                        if (kotlin.math.abs(dx) > dp(5) || kotlin.math.abs(dy) > dp(5)) moved = true
                        if (moved) { p.x = startX + dx; p.y = startY + dy; wm.updateViewLayout(v, p) }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) v.performClick()
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun togglePanel() {
        if (panel != null) {
            try { wm.removeView(panel) } catch (_: Exception) {}
            panel = null; return
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply { setColor(dark); cornerRadius = dp(18).toFloat(); setStroke(dp(2), red) }
        }
        val title = TextView(this).apply {
            text = "♛  F2 PROXY V1.1"; textSize = 19f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(red); setPadding(0,0,0,dp(8))
        }
        box.addView(title)
        box.addView(label("●  PANEL STATUS: VISUAL DEMO", Color.GREEN))
        box.addView(label("REGION: ADNA", Color.LTGRAY))
        listOf("Aim Drak", "Aim Kort", "HS-ESKOLE", "DESERT+ 90HS").forEach { name ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(label(name, Color.WHITE), LinearLayout.LayoutParams(0, dp(42), 1f))
            val toggle = TextView(this).apply {
                text = "BAĞLI"; textSize = 12f; gravity = Gravity.CENTER
                setTextColor(Color.WHITE); setPadding(dp(10), dp(7), dp(10), dp(7))
                background = pill(Color.rgb(50,20,25))
                setOnClickListener {
                    val on = text == "BAĞLI"
                    text = if (on) "AÇIQ" else "BAĞLI"
                    background = pill(if (on) red else Color.rgb(50,20,25))
                    Toast.makeText(this@OverlayService, "$name: ${if (on) "AÇIQ (demo)" else "BAĞLI"}", Toast.LENGTH_SHORT).show()
                }
            }
            row.addView(toggle); box.addView(row)
        }
        val close = Button(this).apply {
            text = "MENYUNU BAĞLA"; isAllCaps = false; setTextColor(Color.WHITE)
            background = pill(Color.rgb(150,0,25)); setOnClickListener { togglePanel() }
        }
        box.addView(close)
        panel = box
        wm.addView(box, lp(dp(285), WindowManager.LayoutParams.WRAP_CONTENT, dp(12), dp(170)))
    }

    private fun label(s: String, c: Int) = TextView(this).apply {
        text = s; textSize = 13f; setTextColor(c); setPadding(0, dp(4), dp(6), dp(4))
    }
    private fun pill(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(12).toFloat(); setStroke(dp(1), red) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        bubble = null; panel = null
        super.onDestroy()
    }
}
