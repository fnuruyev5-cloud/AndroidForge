package com.f2proxy.v11

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val red = Color.rgb(255, 24, 48)
    private val brightRed = Color.rgb(205, 0, 28)
    private val bg = Color.rgb(7, 7, 11)
    private val card = Color.rgb(18, 18, 24)
    private lateinit var root: LinearLayout
    private var loggedIn = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showLogin()
    }

    private fun showLogin() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.f2_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "F2 PROXY logo"
        }
        content.addView(logo, LinearLayout.LayoutParams(dp(210), dp(210)))
        content.addView(text("F2 PROXY", 30f, red, true, Gravity.CENTER))
        content.addView(text("V1.1  •  ADNA EDITION", 13f, Color.LTGRAY, true, Gravity.CENTER))
        val panel = verticalCard()
        panel.addView(text("GİRİŞ / LOGIN", 20f, Color.WHITE, true))
        val user = EditText(this).apply {
            hint = "İstifadəçi adı"
            setSingleLine(true)
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setPadding(dp(14), 0, dp(14), 0)
            background = rounded(Color.rgb(28,28,35), dp(12), Color.rgb(75,25,35))
        }
        val pass = EditText(this).apply {
            hint = "Şifrə"
            setSingleLine(true); inputType = 129
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setPadding(dp(14), 0, dp(14), 0)
            background = rounded(Color.rgb(28,28,35), dp(12), Color.rgb(75,25,35))
        }
        panel.addView(user, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(16) })
        panel.addView(pass, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) })
        panel.addView(action("DAXİL OL", true) {
            if (user.text.toString().trim() == "F2" && pass.text.toString() == "21") {
                loggedIn = true
                showDashboard()
            } else {
                Toast.makeText(this, "İstifadəçi adı və ya şifrə yanlışdır.", Toast.LENGTH_LONG).show()
            }
        }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(16) })
        panel.addView(text("Demo giriş: F2  /  21", 12f, Color.GRAY, false))
        content.addView(panel, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24) })
        content.addView(text("Yalnız vizual panel • Oyun faylları dəyişdirilmir", 12f, Color.GRAY, false, Gravity.CENTER))
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    private fun showDashboard(section: String = "Əsas Səhifə") {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(65,0,12), bg)).apply { cornerRadius = dp(12).toFloat() }
        }
        val logo = ImageView(this).apply { setImageResource(R.drawable.f2_logo); scaleType = ImageView.ScaleType.CENTER_CROP }
        header.addView(logo, LinearLayout.LayoutParams(dp(48), dp(48)))
        val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10),0,0,0) }
        names.addView(text("F2 PROXY", 20f, red, true))
        names.addView(text("V1.1  •  ADNA", 11f, Color.LTGRAY, true))
        header.addView(names, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(text("● ONLINE", 12f, Color.GREEN, true))
        root.addView(header, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(10), dp(10), dp(10), dp(6)) })

        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val navScroll = ScrollView(this)
        val nav = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8),dp(8),dp(8),dp(8)) }
        val navNames = listOf("⌂  Əsas Səhifə", "◎  Proxy", "🎮  FF Panel", "⚙  Ayarlar", "▤  Loglar", "ⓘ  Haqqımızda")
        navNames.forEach { item ->
            nav.addView(action(item, item.contains(section) || (section=="Əsas Səhifə" && item.contains("Əsas"))) {
                val target = when {
                    item.contains("Proxy") -> "Proxy"
                    item.contains("FF Panel") -> "FF Panel"
                    item.contains("Ayarlar") -> "Ayarlar"
                    item.contains("Loglar") -> "Loglar"
                    item.contains("Haqqımızda") -> "Haqqımızda"
                    else -> "Əsas Səhifə"
                }
                showDashboard(target)
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(6) })
        }
        navScroll.addView(nav)
        body.addView(navScroll, LinearLayout.LayoutParams(dp(142), -1))
        val pageScroll = ScrollView(this)
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8),dp(8),dp(12),dp(20)) }
        page.addView(text(section.uppercase(), 22f, red, true))
        page.addView(text("DAHA GÜCLÜ. DAHA CANLI. F2 PROXY V1.1", 12f, Color.LTGRAY, false))
        when (section) {
            "Proxy" -> {
                page.addView(infoCard("PROXY STATUS", "Vizual demo • real proxy bağlantısı yoxdur"))
                page.addView(text("Region seç", 14f, Color.WHITE, true))
                val region = Spinner(this)
                region.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("ADNA", "EUROPE", "ASIA", "MIDDLE EAST"))
                page.addView(region, LinearLayout.LayoutParams(-1, dp(48)))
                page.addView(action("▶  Proxy-i Başlat", true) { Toast.makeText(this, "Bu düymə yalnız demo statusunu dəyişir.", Toast.LENGTH_SHORT).show() })
                page.addView(text("Panel seçimləri yalnız vizualdır; oyunun nişanalma sisteminə təsir etmir.", 12f, Color.GRAY, false))
            }
            "FF Panel" -> {
                page.addView(infoCard("FF PANEL", "Aşağıdakı düymələr vizual demo açarlarıdır. Free Fire faylları dəyişdirilmir."))
                listOf("Aim Drak", "Aim Kort", "HS-ESKOLE", "DESERT+ 90HS").forEach { name ->
                    val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
                    row.addView(text(name, 15f, Color.WHITE, true), LinearLayout.LayoutParams(0, dp(48), 1f))
                    val toggle = Switch(this).apply {
                        textOn = "AÇIQ"; textOff = "BAĞLI"; isChecked = false
                        setTextColor(Color.LTGRAY)
                        buttonTintList = android.content.res.ColorStateList.valueOf(red)
                        setOnCheckedChangeListener { _, checked ->
                            Toast.makeText(this@MainActivity, "$name: ${if (checked) "AÇIQ (demo)" else "BAĞLI"}", Toast.LENGTH_SHORT).show()
                        }
                    }
                    row.addView(toggle)
                    page.addView(row)
                    page.addView(View(this).apply { setBackgroundColor(Color.rgb(45,25,30)) }, LinearLayout.LayoutParams(-1, dp(1)))
                }
                page.addView(action("ÜZƏN F2 MENYUSUNU AÇ", true) { startOverlay() })
            }
            "Ayarlar" -> {
                page.addView(infoCard("GÖRÜNÜŞ", "Qırmızı-qara tema aktivdir"))
                page.addView(action("Üzən menyu icazəsi", false) {
                    if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    else Toast.makeText(this, "İcazə artıq aktivdir.", Toast.LENGTH_SHORT).show()
                })
                page.addView(action("Çıxış", false) { showLogin() })
            }
            "Loglar" -> {
                page.addView(infoCard("SON LOQLAR", "Sistem hazırdır.\nVizual panel açıldı.\nFree Fire faylları dəyişdirilmədi."))
            }
            "Haqqımızda" -> {
                page.addView(infoCard("F2 PROXY ADNA", "Versiya 1.1\nQırmızı-qara vizual idarəetmə paneli.\nReal VPN/proxy və oyun modifikasiyası daxil deyil."))
                page.addView(action("Free Fire-ı aç", true) { launchFreeFire() })
            }
            else -> {
                page.addView(infoCard("PROXY STATUS", "● Aktiv • UI DEMO"))
                page.addView(infoCard("FF PANEL", "Vizual açarlar • oyun fayllarına müdaxilə etmir"))
                val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                grid.addView(action("⚡  Sürətli görünüş", false) { Toast.makeText(this, "Vizual məlumat", Toast.LENGTH_SHORT).show() })
                grid.addView(action("🛡  Təhlükəsizlik", false) { Toast.makeText(this, "Oyun faylları dəyişdirilmir.", Toast.LENGTH_SHORT).show() })
                page.addView(grid)
                page.addView(action("▶  FREE FIRE START", true) { launchFreeFire() })
                page.addView(action("F2 ÜZƏN MENYUNU AÇ", false) { startOverlay() })
            }
        }
        pageScroll.addView(page)
        body.addView(pageScroll, LinearLayout.LayoutParams(0, -1, 1f))
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            startService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "F2 üzən düyməsi aktivdir.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun launchFreeFire() {
        val pkgs = listOf("com.dts.freefireth", "com.dts.freefiremax")
        for (pkg in pkgs) {
            val intent = packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                try { startActivity(intent); return } catch (_: Exception) {}
            }
        }
        Toast.makeText(this, "Free Fire tapılmadı. Oyunun quraşdırıldığını və region versiyasını yoxla.", Toast.LENGTH_LONG).show()
    }

    private fun infoCard(title: String, body: String): View {
        val box = verticalCard()
        box.addView(text(title, 16f, red, true))
        box.addView(text(body, 13f, Color.LTGRAY, false))
        return box
    }

    private fun verticalCard() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(card, dp(16), Color.rgb(100,15,30))
    }

    private fun action(label: String, primary: Boolean, click: () -> Unit) = Button(this).apply {
        text = label
        textSize = 13f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = rounded(if (primary) brightRed else Color.rgb(28,18,23), dp(12), if (primary) red else Color.rgb(80,30,40))
        setPadding(dp(8), dp(6), dp(8), dp(6))
        setOnClickListener { click() }
    }

    private fun text(s: String, size: Float, color: Int, bold: Boolean, gravity: Int = Gravity.START) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); this.gravity = gravity
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(5), 0, dp(5))
    }

    private fun rounded(color: Int, radius: Int, stroke: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat(); setStroke(dp(1), stroke)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
