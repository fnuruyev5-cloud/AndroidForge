# FF BOOSTER — Android Studio starter project

## Açmaq
1. Android Studio quraşdır.
2. `FF_BOOSTER_Android_Studio` qovluğunu Android Studio ilə aç.
3. Gradle sync tamamlanmasını gözlə.
4. Android telefonunu USB ilə qoş və USB debugging icazəsini yalnız öz kompüterində təsdiqlə.
5. Run düyməsi ilə telefonda sına.

## APK yaratmaq
Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s)

APK çıxış yolu adətən:
`app/build/outputs/apk/debug/app-debug.apk`

## Hazırda olanlar
- Kotlin + Jetpack Compose interfeysi
- Free Fire / Free Fire MAX paketini yoxlama və oyunu açma
- RAM və daxili yaddaş göstəriciləri
- USB Debugging statusunu oxuma cəhdi və Developer Options ekranını açma
- Sistem və təhlükəsizlik qeydləri

## Məhdudiyyətlər
- USB debugging proqram tərəfindən səssiz aktivləşdirilə bilməz.
- Bu ilkin versiya ADB host bağlantısını yoxlamır.
- Digər tətbiqlərin keşini silmək və ya onları məcburi bağlamaq mümkün deyil.
- Android-də bütün cihazlar üçün universal CPU faizi və dəqiq batareya/CPU temperaturu API-si yoxdur.
- Termal vəziyyət bu ilkin versiyada yalnız məlumatlandırıcı placeholder-dır; real temperatur kimi göstərilmir.
- Free Fire paket adları region və buraxılışa görə dəyişə bilər.

Bu layihə oyun fayllarını dəyişmir, oyuna kod yeritmir və anti-cheat sistemlərini keçmir.
